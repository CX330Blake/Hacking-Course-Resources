BOOL DeleteSelf() {
	WCHAR                       szPath[MAX_PATH * 2] = { 0 };
	FILE_DISPOSITION_INFO       Delete = { 0 };
	HANDLE                      hFile = INVALID_HANDLE_VALUE;
	PFILE_RENAME_INFO           pRename = NULL;
	const wchar_t* NewStream = (const wchar_t*)L":BYE";
	SIZE_T			            StreamLength = wcslen(NewStream) * sizeof(wchar_t);
	SIZE_T                      sRename = sizeof(FILE_RENAME_INFO) + StreamLength;


	// Allocating enough buffer for the 'FILE_RENAME_INFO' structure
	pRename = (PFILE_RENAME_INFO) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sRename);
	if (!pRename) {
		printf("[!] HeapAlloc Failed With Error : %d \n", GetLastError());
		return FALSE;
	}

	ZeroMemory(szPath, sizeof(szPath));
	ZeroMemory(&Delete, sizeof(FILE_DISPOSITION_INFO));

	pRename->FileNameLength = StreamLength;
	RtlCopyMemory(pRename->FileName, NewStream, StreamLength);

	// Get the full path of the current file
	if (GetModuleFileNameW(NULL, szPath, MAX_PATH * 2) == 0) {
		return FALSE;
	}

	// Opening a handle to the current file
	hFile = CreateFileW(szPath, DELETE | SYNCHRONIZE, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		printf("[!] CreateFileW [R] Failed With Error : %d \n", GetLastError());
		return FALSE;
	}

	// Renaming the data stream
	if (!SetFileInformationByHandle(hFile, FileRenameInfo, pRename, sRename)) {
		printf("[!] SetFileInformationByHandle [R] Failed With Error : %d \n", GetLastError());
		return FALSE;
	}

	CloseHandle(hFile);

	// DELETING
	hFile = CreateFileW(szPath, DELETE | SYNCHRONIZE, FILE_SHARE_READ, NULL, OPEN_EXISTING, NULL, NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		return FALSE;
	}

	Delete.DeleteFile = TRUE;
	if (!SetFileInformationByHandle(hFile, FileDispositionInfo, &Delete, sizeof(Delete))) {
		return FALSE;
	}
	CloseHandle(hFile);
	HeapFree(GetProcessHeap(), 0, pRename);

	return TRUE;
}
