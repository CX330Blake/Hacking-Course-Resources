#include <windows.h>
#include <winternl.h>
#include <stdio.h>

// Function to find a module base address by name using PEB
PVOID GetModuleBase(LPCWSTR moduleName) {
    PVOID moduleBase = NULL;

#ifdef _WIN64
    PPEB peb = (PPEB)__readgsqword(0x60); // Get PEB in x64
#else
    PPEB peb = (PPEB)__readfsdword(0x30); // Get PEB in x86
#endif
    
    PPEB_LDR_DATA ldr = peb->Ldr;
    PLIST_ENTRY head = &ldr->InMemoryOrderModuleList;
    PLIST_ENTRY current = head->Flink;

    while (current != head) {
        // This one is correct
        PLDR_DATA_TABLE_ENTRY entry = CONTAINING_RECORD(current, LDR_DATA_TABLE_ENTRY, InMemoryOrderLinks);
        // This one is hack
        PLDR_DATA_TABLE_ENTRY pDte = (PLDR_DATA_TABLE_ENTRY)current;

        const wchar_t* baseName = (wchar_t*)pDte->FullDllName.Buffer;
        wprintf(L"[Module] %ls\n", baseName);
        if (baseName && lstrcmpW(baseName, moduleName) == 0) {
            moduleBase = entry->DllBase;
            break;
        }
        current = current->Flink;
    }

    return moduleBase;
}

// Function to find an exported function address using GetProcAddress logic
PVOID GetProcAddressCustom(PVOID moduleBase, LPCSTR procName) {
    PIMAGE_DOS_HEADER dosHeader = (PIMAGE_DOS_HEADER)moduleBase;
    PIMAGE_NT_HEADERS ntHeaders = (PIMAGE_NT_HEADERS)((BYTE*)moduleBase + dosHeader->e_lfanew);

    DWORD exportDirRVA = ntHeaders->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress;
    if (exportDirRVA == 0) return NULL;

    PIMAGE_EXPORT_DIRECTORY exportDir = (PIMAGE_EXPORT_DIRECTORY)((BYTE*)moduleBase + exportDirRVA);

    DWORD* nameRVA = (DWORD*)((BYTE*)moduleBase + exportDir->AddressOfNames);
    WORD* ordinalRVA = (WORD*)((BYTE*)moduleBase + exportDir->AddressOfNameOrdinals);
    DWORD* functionRVA = (DWORD*)((BYTE*)moduleBase + exportDir->AddressOfFunctions);

    for (DWORD i = 0; i < exportDir->NumberOfNames; i++) {
        char* functionName = (char*)((BYTE*)moduleBase + nameRVA[i]);
        if (strcmp(functionName, procName) == 0) {
            WORD ordinal = ordinalRVA[i];
            return (PVOID)((BYTE*)moduleBase + functionRVA[ordinal]);
        }
    }

    return NULL;
}

int main() {
    // Bring in the user32.dll
    LoadLibraryA("user32.dll");

    // Example usage: Get base of user32.dll and address of MessageBoxA
    const wchar_t* moduleName = L"user32.dll";
    const char* functionName = "MessageBoxA";

    PVOID user32Base = GetModuleBase(moduleName);
    if (!user32Base) {
        printf("Failed to find module: %ls\n", moduleName);
        return -1;
    }

    printf("Module base of %ls: %p\n", moduleName, user32Base);

    PVOID functionAddress = GetProcAddressCustom(user32Base, functionName);
    if (!functionAddress) {
        printf("Failed to find function: %s\n", functionName);
        return -1;
    }

    printf("Function address of %s: %p\n", functionName, functionAddress);

    // Call MessageBoxA using the resolved address
    typedef int (WINAPI* MESSAGEBOXA)(HWND, LPCSTR, LPCSTR, UINT);
    MESSAGEBOXA MessageBoxA = (MESSAGEBOXA)functionAddress;

    MessageBoxA(NULL, "Hello, World!", "MessageBoxA Example", MB_OK);

    return 0;
}
